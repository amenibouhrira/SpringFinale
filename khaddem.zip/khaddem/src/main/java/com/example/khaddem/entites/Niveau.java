package com.example.khaddem.entites;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


public enum Niveau {
    JUNIOR,
    SENIOR,
    EXPERT,
}