package com.example.khaddem.Services;



public interface ContratService {
    void retrieveAndUpdateStatusContrat();

}
