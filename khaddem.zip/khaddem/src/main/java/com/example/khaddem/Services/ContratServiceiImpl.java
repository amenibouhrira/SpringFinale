package com.example.khaddem.Services;

import com.example.khaddem.entites.Contrat;
import com.example.khaddem.repositories.ContratRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
@AllArgsConstructor
@Service
@Slf4j
public class ContratServiceiImpl implements ContratService {
    ContratRepository contratRepository ;
    @Scheduled(fixedDelay = 20000 )
    @Override
    public void retrieveAndUpdateStatusContrat() {
        Date dateLimite = new Date(System.currentTimeMillis() + 15 * 24 * 60 * 60 * 1000);
        List<Contrat> listContrat= contratRepository.findByDateFinContratBeforeAndArchiveIsFalse(dateLimite);
        listContrat.stream().filter(new Predicate<Contrat>() {
            @Override
            public boolean test(Contrat contrat) {
                if (dateLimite.getTime()-contrat.getDateFinContrat().getTime()>0) {
                    return true;
                }
                else return false;
            }
        }).forEach(new Consumer<Contrat>() {
            @Override
            public void accept(Contrat contrat) {

                  log.info("etudiant de l'etudiant)"+contrat.getEtudiant().getNomE()+"est près d'être fini!");
            }
        });
    }

}
