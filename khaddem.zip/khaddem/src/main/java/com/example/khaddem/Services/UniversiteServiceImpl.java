package com.example.khaddem.Services;
import com.example.khaddem.entites.Department;
import com.example.khaddem.entites.Etudiant;
import com.example.khaddem.entites.Universite;
import com.example.khaddem.repositories.EtudiantRepository;
import com.example.khaddem.repositories.UniversiteRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@AllArgsConstructor
@Service
public class UniversiteServiceImpl implements UniversiteService{
    UniversiteRepository universiteRepository;
    @Override
    public List<Universite> retrieveAllUniversite(){
        return (List<Universite>) universiteRepository.findAll();
    }

    @Override
    public  Universite addUniversite(Universite u, Department d) {

        Set<Department> departments=u.getDepartments();
        departments.add(d);
        return universiteRepository.save(u);
    }

    @Override
    public Universite updateUniversite(Universite universite, Integer idUniversite) {
        Universite universite1 = universiteRepository.findById(idUniversite).get();
        universite1.setNomUniv(universite.getNomUniv());

        return universiteRepository.save(universite1);
    }

    @Override
    public Universite retrieveUniversite(Integer idUniversite) {
        return universiteRepository.findById(idUniversite).get();
    }

    @Override
    public void deleteUniversite(Integer idUniversite) {

        universiteRepository.deleteById(idUniversite);

    }
    @Override
    public List<Department> retrieveDepartementsByUniversite(Integer idUniversite){
        return  universiteRepository.findDepartmentsByIdUniv(idUniversite);
    }


}
