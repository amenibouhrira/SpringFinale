package com.example.khaddem.entites;

public enum Specialite {
    IA,
    RESEAUX,
    CLOUD,
    SECURITE
}
