package com.example.khaddem.Services;
import com.example.khaddem.entites.Department;
import com.example.khaddem.entites.Etudiant;
import com.example.khaddem.entites.Universite;
import com.example.khaddem.repositories.DepartmentRepository;
import com.example.khaddem.repositories.EtudiantRepository;
import com.example.khaddem.repositories.UniversiteRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@AllArgsConstructor
@Service
public class DepartmentServiceImpl implements DepartementService{
    DepartmentRepository departmentRepository;
    EtudiantRepository etudiantRepository;
    @Override
    public List<Department> retrieveAllDepartment(){
        return (List<Department>) departmentRepository.findAll();
    }

    @Override
    public  Department addDepartment(Department e) {
        return departmentRepository.save(e);
    }

    @Override
    public Department updateDepartment(Department department, Integer idDepartment) {
        Department department1 = departmentRepository.findById(idDepartment).get();
        department1.setNomDepart(department.getNomDepart());

        return departmentRepository.save(department1);
    }

    @Override
    public Department retrieveDepartment(Integer idDepartment) {
        return departmentRepository.findById(idDepartment).get();
    }

    @Override
    public void deleteDepartment(Integer idDepartment) {

        departmentRepository.deleteById(idDepartment);

    }


}
