package com.example.khaddem.Controller;

import com.example.khaddem.Services.EtudiantService;
import com.example.khaddem.entites.Etudiant;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/etudiant")
public class EtudiantRestController {
    EtudiantService etudiantService;
    // http://localhost:8089/kaddem/etudiant/retrieve-all-etudiants
    @GetMapping("/retrieve-all-etudiants")
    public List<Etudiant> getEtudiants() {
        List<Etudiant> listEtudiants = etudiantService.retrieveAllEtudiants();
        return listEtudiants;
    }
    // http://localhost:8089/kaddem/etudiant/retrieve-etudiant/8
    @GetMapping("/retrieve-etudiant/{etudiantId}")
    public Etudiant retrieveEtudiant(@PathVariable("etudiantId") Integer etudiantId) {
        return etudiantService.retrieveEtudiant(etudiantId);
    }
    // http://localhost:8089/kaddem/etudiant/add-etudiant
    @PostMapping("/add-etudiant")
    public Etudiant addEtudiant(@RequestBody Etudiant e) {
        Etudiant etudiant = etudiantService.addEtudiant(e);
        return etudiant;
    }
    // http://localhost:8089/kaddem/etudiant/update-etudiant
    @PutMapping("/update-etudiant/{etudiantId}")
    public Etudiant updateEtudiant(@RequestBody Etudiant e, @PathVariable Integer etudiantId) {
         return etudiantService.updateEtudiant(e,etudiantId);

    }
    // http://localhost:8089/kaddem/etudiant/update-etudiant
    //@PutMapping("/affect_Etudiant_Dept/{etudiantId}/{departmentId]")
    //public Etudiant affectEtudianttoDept(@RequestBody Integer etudiantId, @PathVariable Integer departmentId) {
      //  return etudiantService.assignEtudiantToDepartement(etudiantId,departmentId);
    @PutMapping(value="/add-etud-department/{etudiantId}/{departementId}")
    public void affecterEtudiantToDepartement(@PathVariable("etudiantId") Integer etudiantId, @PathVariable("departementId")Integer departementId){
        etudiantService.assignEtudiantToDepartement(etudiantId, departementId);

    }

    // http://localhost:8089/kaddem/etudiant/delete-etudiant
    @DeleteMapping("/delete-etudiant/{etudiant-id}")
    public void deleteEtudiant(@PathVariable("etudiant-id") Integer etudiantId) {
        etudiantService.deleteEtudiant(etudiantId);
    }
    @PostMapping("/asgin-etudiant-contrat-equipe/{idContrat}/{idEquipe}")
    public Etudiant addAndAssignEtudiantToEquipeAndContract(
            @RequestBody Etudiant etudiant,
            @PathVariable("idContrat") Integer idContrat,
            @PathVariable("idEquipe")  Integer idEquipe
    ){
        return etudiantService.addAndAssignEtudiantToEquipeAndContract(etudiant, idContrat, idEquipe);
    }

    }


