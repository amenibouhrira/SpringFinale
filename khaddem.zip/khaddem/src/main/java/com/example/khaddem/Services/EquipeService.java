package com.example.khaddem.Services;

import com.example.khaddem.entites.Equipe;


import java.util.List;


public interface EquipeService {
    List<Equipe> retrieveAllEquipes();

    Equipe addEquipe(Equipe e);



    Equipe updateEquipe(Equipe equipe, Integer idEquipe);

    Equipe retrieveEquipe (Integer idEquipe);


    void deleteEquipe(Integer idEquipe);

}
