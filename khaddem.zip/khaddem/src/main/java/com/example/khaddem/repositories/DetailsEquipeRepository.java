package com.example.khaddem.repositories;

import com.example.khaddem.entites.Contrat;
import com.example.khaddem.entites.DetailsEquipe;
import org.springframework.data.repository.CrudRepository;

public interface DetailsEquipeRepository extends CrudRepository<DetailsEquipe,Integer> {

}
