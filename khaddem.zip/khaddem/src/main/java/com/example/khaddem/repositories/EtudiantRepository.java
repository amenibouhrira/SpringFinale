package com.example.khaddem.repositories;

import com.example.khaddem.entites.Contrat;
import com.example.khaddem.entites.Etudiant;
import com.example.khaddem.entites.Niveau;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EtudiantRepository extends CrudRepository<Etudiant,Integer> {
    public List<Etudiant> findByDepartmentNomDepart(String nomDepart);

    public List<Etudiant> findByEquipesNiveau(Niveau niv);

}
