package com.example.khaddem.Services;
import com.example.khaddem.entites.Contrat;
import com.example.khaddem.entites.Department;
import com.example.khaddem.entites.Equipe;
import com.example.khaddem.entites.Etudiant;
import com.example.khaddem.repositories.ContratRepository;
import com.example.khaddem.repositories.DepartmentRepository;
import com.example.khaddem.repositories.EquipeRepository;
import com.example.khaddem.repositories.EtudiantRepository;
import lombok.AllArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@AllArgsConstructor
@Service
public class EtudiantServiceImpl implements EtudiantService{
    EtudiantRepository etudiantRepository;
    ContratRepository contratRepository;
    EquipeRepository equipeRepository;
    @Override
    public List<Etudiant> retrieveAllEtudiants(){
        return (List<Etudiant>) etudiantRepository.findAll();
    }

    @Override
    public  Etudiant addEtudiant(Etudiant e) {
        return etudiantRepository.save(e);
    }

    @Override
    public Etudiant updateEtudiant(Etudiant etudiant, Integer idEtudiant) {
        Etudiant etudiant1 = etudiantRepository.findById(idEtudiant).get();
        etudiant1.setPrenomE(etudiant.getPrenomE());
        etudiant1.setNomE(etudiant.getNomE());
        etudiant1.setOp(etudiant.getOp());

        return etudiantRepository.save(etudiant1);
    }

    @Override
    public Etudiant retrieveEtudiant(Integer idEtudiant) {
        return etudiantRepository.findById(idEtudiant).get();
    }

    @Override
    public void deleteEtudiant(Integer idEtudiant) {

        etudiantRepository.deleteById(idEtudiant);

    }
    DepartmentRepository departmentRepository;
    @Override
    public Etudiant assignEtudiantToDepartement(Integer etudiantId, Integer departementId) {
        Department department = departmentRepository.findById(departementId).get();
        Etudiant e =etudiantRepository.findById(etudiantId).get();
        e.setDepartment(department);
        etudiantRepository.save(e);
        return e;
    }
    @Transactional
    public Etudiant addAndAssignEtudiantToEquipeAndContract(Etudiant e, Integer idContrat, Integer idEquipe) {
        Equipe equipe = equipeRepository.findById(idEquipe).get();
        Contrat contrat = contratRepository.findById(idContrat).get();
        Etudiant etudiant = etudiantRepository.save(e);
        equipe.getEtudiants().add(etudiant);
        equipeRepository.save(equipe);
        contrat.setEtudiant(etudiant);
        contratRepository.save(contrat);
        return e;
    }

}
