package com.example.khaddem.entites;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table( name = "Contrat")
public class Contrat implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idContrat")
    private Integer idContrat; // Clé primaire
    private Date dateDebutContrat;
    private Date dateFinContrat;
    private boolean archive;
    private Integer montantContrat;
    @Enumerated(EnumType.STRING)
    private Specialite sep;
    @ManyToOne
    Etudiant etudiant;
}
