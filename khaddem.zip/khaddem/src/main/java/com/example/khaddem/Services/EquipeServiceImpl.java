package com.example.khaddem.Services;

import com.example.khaddem.entites.Equipe;
import com.example.khaddem.repositories.ContratRepository;
import com.example.khaddem.repositories.EquipeRepository;
import lombok.AllArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
@AllArgsConstructor
@Service
public class EquipeServiceImpl implements EquipeService{
    EquipeRepository equipeRepository;

    @Override
    public List<Equipe> retrieveAllEquipes() {
        return (List<Equipe>) equipeRepository.findAll();
    }

    @Override
    public Equipe addEquipe(Equipe e) {
        return equipeRepository.save(e);
    }

    @Override
    public Equipe updateEquipe(Equipe equipe, Integer idEquipe) {
        Equipe equipe1 = equipeRepository.findById(idEquipe).get();
        equipe1.setNomEquipe(equipe.getNomEquipe());
        equipe1.setNiveau(equipe.getNiveau());
        equipe1.setDetailEquipe(equipe.getDetailEquipe());

        return equipeRepository.save(equipe1);
    }

    @Override
    public Equipe retrieveEquipe(Integer idEquipe) {
        return equipeRepository.findById(idEquipe).get();
    }

    @Override
    public void deleteEquipe(Integer idEquipe) {

         equipeRepository.deleteById(idEquipe);

    }

}
