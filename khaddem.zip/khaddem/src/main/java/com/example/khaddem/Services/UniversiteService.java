package com.example.khaddem.Services;


import com.example.khaddem.entites.Department;
import com.example.khaddem.entites.Universite;
import com.example.khaddem.entites.Department;
import java.util.List;


public interface UniversiteService {
    List<Universite> retrieveAllUniversite();

    Universite addUniversite(Universite e, Department d);



    Universite updateUniversite(Universite universite, Integer idUniversite);

    Universite retrieveUniversite (Integer idUniversite);


    void deleteUniversite(Integer idUniversite);
     List<Department> retrieveDepartementsByUniversite(Integer idUniversite);

}
