package com.example.khaddem.Services;

import com.example.khaddem.entites.Etudiant;

import java.util.List;


public interface EtudiantService {
    List<Etudiant> retrieveAllEtudiants();

    Etudiant addEtudiant(Etudiant e);



    Etudiant updateEtudiant(Etudiant etudiant, Integer idEtudiant);

    Etudiant retrieveEtudiant (Integer idEtudiant);


    void deleteEtudiant(Integer idEtudiant);
    Etudiant assignEtudiantToDepartement (Integer etudiantId , Integer departementId );
    Etudiant addAndAssignEtudiantToEquipeAndContract(Etudiant e, Integer idContrat, Integer idEquipe);
}
