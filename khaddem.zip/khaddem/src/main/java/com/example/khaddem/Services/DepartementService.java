package com.example.khaddem.Services;


import com.example.khaddem.entites.Department;
import com.example.khaddem.entites.Universite;

import java.util.List;


public interface DepartementService {
    List<Department> retrieveAllDepartment();

    Department addDepartment(Department e);


    Department updateDepartment(Department department, Integer idDepartment);

    Department retrieveDepartment(Integer idDepartment);


    void deleteDepartment(Integer idDepartment);

}