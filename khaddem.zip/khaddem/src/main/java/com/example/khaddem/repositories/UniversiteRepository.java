package com.example.khaddem.repositories;

import com.example.khaddem.entites.Department;
import com.example.khaddem.entites.Specialite;
import com.example.khaddem.entites.Universite;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UniversiteRepository extends CrudRepository<Universite,Integer> {
    List<Department> findDepartmentsByIdUniv(Integer idUniv);
  //
}
