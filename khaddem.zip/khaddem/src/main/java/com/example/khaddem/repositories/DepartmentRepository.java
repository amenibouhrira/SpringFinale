package com.example.khaddem.repositories;

import com.example.khaddem.entites.Department;
import com.example.khaddem.entites.Equipe;
import org.springframework.data.repository.CrudRepository;

public interface DepartmentRepository extends CrudRepository<Department,Integer> {



}
