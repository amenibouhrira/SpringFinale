package com.example.khaddem.Controller;

import com.example.khaddem.Services.EquipeService;
import com.example.khaddem.entites.Equipe;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@Tag(name="Equipe Mnagement")
@RestController
@AllArgsConstructor
@RequestMapping("/equipe")
public class EquipeRestController {
    EquipeService equipeService;
    @Operation(description=" Retrieve all equipe")
    // http://localhost:8089/kaddem/equipe/retrieve-all-equipes
    @GetMapping("/retrieve-all-equipes")
    public List<Equipe> getEquipes() {
        List<Equipe> listEquipes = equipeService.retrieveAllEquipes();
        return listEquipes;
    }
    // http://localhost:8089/kaddem/equipe/retrieve-equipe/8
    @GetMapping("/retrieve-equipe/{equipeId}")
    public Equipe retrieveEquipe(@PathVariable("equipeId") Integer equipeId) {
        return equipeService.retrieveEquipe(equipeId);
    }
    // http://localhost:8089/kaddem/equipe/add-equipe
    @PostMapping("/add-equipe")
    public Equipe addEquipe(@RequestBody Equipe e) {
        Equipe equipe = equipeService.addEquipe(e);
        return equipe;
    }
    // http://localhost:8089/kaddem/equipe/update-equipe
    @PutMapping("/update-equipe/{equipeId}")
    public Equipe updateEquipe(@RequestBody Equipe e, @PathVariable Integer equipeId) {
         return equipeService.updateEquipe(e,equipeId);

    }

    // http://localhost:8089/kaddem/equipe/delete-equipe
    @DeleteMapping("/delete-equipe/{equipe-id}")
    public void deleteEquipe(@PathVariable("equipe-id") Integer equipeId) {
        equipeService.deleteEquipe(equipeId);
    }
}
