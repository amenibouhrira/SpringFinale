package com.example.khaddem.repositories;

import com.example.khaddem.entites.Contrat;
import com.example.khaddem.entites.Department;
import org.springframework.data.repository.CrudRepository;

import java.util.Date;
import java.util.List;

public interface ContratRepository extends CrudRepository<Contrat,Integer> {
    public List<Contrat> findByDateFinContratBeforeAndArchiveIsFalse(Date date);

}
